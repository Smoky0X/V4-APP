"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Check, Crown, Zap, Users, Building2 } from "lucide-react"
import { subscriptionPlans } from "@/lib/subscription-service"

interface SubscriptionModalProps {
  isOpen: boolean
  onClose: () => void
  currentPlan: string
  userType: "particulier" | "professionnel"
  onUpgrade: (plan: string) => void
}

export function SubscriptionModal({ isOpen, onClose, currentPlan, userType, onUpgrade }: SubscriptionModalProps) {
  const [selectedPlan, setSelectedPlan] = useState(currentPlan)

  const particularPlans = ["gratuite", "premium", "ultimate"]
  const professionalPlans = ["pro-start", "pro-plus", "pro-elite"]

  const getPlansForType = (type: "particulier" | "professionnel") => {
    return type === "particulier" ? particularPlans : professionalPlans
  }

  const handleUpgrade = () => {
    onUpgrade(selectedPlan)
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-3xl text-center bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Choisissez votre abonnement CarWize AI
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue={userType} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="particulier" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Particulier
            </TabsTrigger>
            <TabsTrigger value="professionnel" className="flex items-center gap-2">
              <Building2 className="h-4 w-4" />
              Professionnel
            </TabsTrigger>
          </TabsList>

          <TabsContent value="particulier" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {particularPlans.map((planKey) => {
                const plan = subscriptionPlans[planKey]
                return (
                  <Card
                    key={planKey}
                    className={`cursor-pointer transition-all ${
                      selectedPlan === planKey ? "ring-2 ring-blue-500 scale-105" : ""
                    } ${planKey === "premium" ? "border-blue-500 relative" : ""}`}
                    onClick={() => setSelectedPlan(planKey)}
                  >
                    {planKey === "premium" && (
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                        <Badge className="bg-blue-500 text-white">
                          <Crown className="h-3 w-3 mr-1" />
                          Populaire
                        </Badge>
                      </div>
                    )}

                    <CardHeader className="text-center">
                      <div className="flex justify-center mb-2">
                        {planKey === "gratuite" && <div className="h-8 w-8" />}
                        {planKey === "premium" && <Crown className="h-8 w-8 text-blue-500" />}
                        {planKey === "ultimate" && <Zap className="h-8 w-8 text-purple-500" />}
                      </div>
                      <CardTitle className="capitalize">{plan.name}</CardTitle>
                      <CardDescription>
                        <span className="text-3xl font-bold">{plan.price === 0 ? "Gratuit" : `${plan.price}€`}</span>
                        {plan.price > 0 && <span className="text-sm">/mois</span>}
                      </CardDescription>
                    </CardHeader>

                    <CardContent>
                      <ul className="space-y-2 mb-4">
                        {plan.features.map((feature, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span className="text-sm">{feature}</span>
                          </li>
                        ))}
                      </ul>

                      <div className="text-xs text-gray-600 space-y-1">
                        <div>Recherches IA: {plan.aiSearches === -1 ? "Illimitées" : plan.aiSearches}</div>
                        <div>Favoris: {plan.maxFavorites === -1 ? "Illimités" : plan.maxFavorites}</div>
                        <div>Alertes prix: {plan.priceAlerts ? "✓" : "✗"}</div>
                        <div>Analyse marché: {plan.marketAnalysis ? "✓" : "✗"}</div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          <TabsContent value="professionnel" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {professionalPlans.map((planKey) => {
                const plan = subscriptionPlans[planKey]
                return (
                  <Card
                    key={planKey}
                    className={`cursor-pointer transition-all ${
                      selectedPlan === planKey ? "ring-2 ring-green-500 scale-105" : ""
                    } ${planKey === "pro-plus" ? "border-green-500 relative" : ""}`}
                    onClick={() => setSelectedPlan(planKey)}
                  >
                    {planKey === "pro-plus" && (
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                        <Badge className="bg-green-500 text-white">
                          <Crown className="h-3 w-3 mr-1" />
                          Recommandé
                        </Badge>
                      </div>
                    )}

                    <CardHeader className="text-center">
                      <div className="flex justify-center mb-2">
                        {planKey === "pro-start" && <Building2 className="h-8 w-8 text-green-500" />}
                        {planKey === "pro-plus" && <Crown className="h-8 w-8 text-green-500" />}
                        {planKey === "pro-elite" && <Zap className="h-8 w-8 text-purple-500" />}
                      </div>
                      <CardTitle>{plan.name}</CardTitle>
                      <CardDescription>
                        <span className="text-3xl font-bold">{plan.price}€</span>
                        <span className="text-sm">/mois</span>
                      </CardDescription>
                    </CardHeader>

                    <CardContent>
                      <ul className="space-y-2 mb-4">
                        {plan.features.map((feature, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span className="text-sm">{feature}</span>
                          </li>
                        ))}
                      </ul>

                      <div className="text-xs text-gray-600 space-y-1">
                        <div>Multi-diffusion: {plan.multiPosting ? "✓" : "✗"}</div>
                        <div>CRM: {plan.crmAccess ? "✓" : "✗"}</div>
                        <div>Chatbot IA: {plan.chatbotAccess ? "✓" : "✗"}</div>
                        <div>Analyse marché: {plan.marketAnalysis ? "✓" : "✗"}</div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-center gap-4 mt-8">
          <Button variant="outline" onClick={onClose}>
            Annuler
          </Button>
          <Button
            onClick={handleUpgrade}
            disabled={selectedPlan === currentPlan}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            {selectedPlan === currentPlan ? "Plan actuel" : "Mettre à niveau"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
