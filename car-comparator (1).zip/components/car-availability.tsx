"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MapPin, Phone, Clock, Car, Percent } from "lucide-react"
import type { CarAvailability } from "@/types"

interface CarAvailabilityProps {
  availability: CarAvailability[]
  carName: string
}

export function CarAvailabilityComponent({ availability, carName }: CarAvailabilityProps) {
  const handleContactDealer = (dealer: CarAvailability) => {
    window.open(`tel:${dealer.dealerPhone}`, "_self")
  }

  const handleGetDirections = (address: string) => {
    const encodedAddress = encodeURIComponent(address)
    window.open(`https://maps.google.com?q=${encodedAddress}`, "_blank")
  }

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold">Disponibilité - {carName}</h3>

      {availability.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <Car className="h-8 w-8 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Aucun véhicule disponible actuellement</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {availability.map((dealer) => (
            <Card key={dealer.dealerId} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{dealer.dealerName}</CardTitle>
                    <div className="flex items-center gap-1 text-gray-600 mt-1">
                      <MapPin className="h-4 w-4" />
                      <span className="text-sm">{dealer.dealerAddress}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-blue-600">{dealer.price.toLocaleString()}€</div>
                    {dealer.discount && (
                      <div className="flex items-center gap-1 text-green-600">
                        <Percent className="h-3 w-3" />
                        <span className="text-sm">-{dealer.discount.toLocaleString()}€</span>
                      </div>
                    )}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <div className="font-medium text-gray-700">Stock</div>
                    <div className="flex items-center gap-1">
                      <Car className="h-4 w-4 text-blue-500" />
                      <span>
                        {dealer.stock} véhicule{dealer.stock > 1 ? "s" : ""}
                      </span>
                    </div>
                  </div>

                  <div>
                    <div className="font-medium text-gray-700">Livraison</div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4 text-orange-500" />
                      <span>{dealer.deliveryTime}</span>
                    </div>
                  </div>

                  <div>
                    <div className="font-medium text-gray-700">Essai</div>
                    <Badge variant={dealer.testDriveAvailable ? "default" : "secondary"}>
                      {dealer.testDriveAvailable ? "Disponible" : "Non disponible"}
                    </Badge>
                  </div>

                  <div>
                    <div className="font-medium text-gray-700">Contact</div>
                    <div className="flex items-center gap-1">
                      <Phone className="h-4 w-4 text-green-500" />
                      <span>{dealer.dealerPhone}</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button variant="outline" size="sm" onClick={() => handleGetDirections(dealer.dealerAddress)}>
                    <MapPin className="h-4 w-4 mr-1" />
                    Itinéraire
                  </Button>

                  <Button variant="outline" size="sm" onClick={() => handleContactDealer(dealer)}>
                    <Phone className="h-4 w-4 mr-1" />
                    Appeler
                  </Button>

                  {dealer.testDriveAvailable && <Button size="sm">Réserver essai</Button>}
                </div>

                {dealer.discount && (
                  <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                    <div className="text-sm text-green-800">
                      <strong>Offre spéciale:</strong> Remise de {dealer.discount.toLocaleString()}€ sur ce véhicule !
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
