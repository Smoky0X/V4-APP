"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, Camera, Brain, Sparkles, Share2, CheckCircle, Loader2 } from "lucide-react"
// Corriger l'import
import { AICarAdvisor } from "@/lib/ai-service"
import type { Vehicle, User } from "@/types"

interface SellVehicleFormProps {
  user: User | null
  onSubmit: (listing: any) => void
}

export function SellVehicleForm({ user, onSubmit }: SellVehicleFormProps) {
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [aiOptimizing, setAiOptimizing] = useState(false)

  const [formData, setFormData] = useState({
    brand: "",
    model: "",
    variant: "",
    year: "",
    mileage: "",
    price: "",
    fuelType: "",
    transmission: "",
    color: "",
    description: "",
    features: [] as string[],
    images: [] as string[],
    platforms: [] as string[],
  })

  const [aiSuggestions, setAiSuggestions] = useState<{
    titleSuggestion: string
    descriptionSuggestion: string
    priceSuggestion: number
    improvementTips: string[]
  } | null>(null)

  const handleInputChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleFeatureToggle = (feature: string) => {
    setFormData((prev) => ({
      ...prev,
      features: prev.features.includes(feature)
        ? prev.features.filter((f) => f !== feature)
        : [...prev.features, feature],
    }))
  }

  const handlePlatformToggle = (platform: string) => {
    setFormData((prev) => ({
      ...prev,
      platforms: prev.platforms.includes(platform)
        ? prev.platforms.filter((p) => p !== platform)
        : [...prev.platforms, platform],
    }))
  }

  const optimizeWithAI = async () => {
    setAiOptimizing(true)

    try {
      const vehicleData: Partial<Vehicle> = {
        brand: formData.brand,
        model: formData.model,
        year: Number.parseInt(formData.year),
        mileage: Number.parseInt(formData.mileage),
        price: Number.parseInt(formData.price),
        fuelType: formData.fuelType,
      }

      // Dans optimizeWithAI, utiliser la bonne méthode:
      const suggestions = (await AICarAdvisor.optimizeListing?.(vehicleData)) || {
        titleSuggestion: `${vehicleData.brand} ${vehicleData.model} ${vehicleData.year}`,
        descriptionSuggestion: "Description optimisée par l'IA",
        priceSuggestion: vehicleData.price || 0,
        improvementTips: ["Ajoutez plus de photos", "Détaillez l'historique"],
      }
      setAiSuggestions(suggestions)
    } catch (error) {
      console.error("AI optimization failed:", error)
    } finally {
      setAiOptimizing(false)
    }
  }

  const applySuggestion = (field: string, value: any) => {
    handleInputChange(field, value)
  }

  const handleSubmit = async () => {
    setLoading(true)

    // Simulate submission
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const listing = {
      ...formData,
      aiSuggestions,
      status: "draft",
      createdAt: new Date(),
    }

    onSubmit(listing)
    setLoading(false)
  }

  const availableFeatures = [
    "Climatisation",
    "GPS",
    "Bluetooth",
    "Régulateur de vitesse",
    "Sièges chauffants",
    "Toit ouvrant",
    "Caméra de recul",
    "Aide au stationnement",
    "Démarrage sans clé",
    "Écran tactile",
    "Jantes alliage",
    "Feux LED",
  ]

  const platforms = [
    { id: "leboncoin", name: "Le Bon Coin", popular: true },
    { id: "lacentrale", name: "La Centrale", popular: true },
    { id: "autoscout24", name: "AutoScout24", popular: false },
    { id: "paruvendu", name: "ParuVendu", popular: false },
    { id: "facebook", name: "Facebook Marketplace", popular: true },
  ]

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Share2 className="h-6 w-6 text-blue-600" />
            Vendre mon véhicule
          </CardTitle>
          <CardDescription>
            Créez votre annonce optimisée par l'IA et diffusez-la sur plusieurs plateformes
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs value={step.toString()} onValueChange={(value) => setStep(Number.parseInt(value))}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="1">Informations</TabsTrigger>
          <TabsTrigger value="2">Photos & Description</TabsTrigger>
          <TabsTrigger value="3">Optimisation IA</TabsTrigger>
          <TabsTrigger value="4">Diffusion</TabsTrigger>
        </TabsList>

        {/* Step 1: Basic Information */}
        <TabsContent value="1" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Informations du véhicule</CardTitle>
              <CardDescription>Renseignez les informations de base de votre véhicule</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="brand">Marque *</Label>
                  <Select value={formData.brand} onValueChange={(value) => handleInputChange("brand", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionnez une marque" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="peugeot">Peugeot</SelectItem>
                      <SelectItem value="renault">Renault</SelectItem>
                      <SelectItem value="citroën">Citroën</SelectItem>
                      <SelectItem value="volkswagen">Volkswagen</SelectItem>
                      <SelectItem value="bmw">BMW</SelectItem>
                      <SelectItem value="mercedes">Mercedes</SelectItem>
                      <SelectItem value="audi">Audi</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="model">Modèle *</Label>
                  <Input
                    id="model"
                    value={formData.model}
                    onChange={(e) => handleInputChange("model", e.target.value)}
                    placeholder="Ex: 208, Clio, Golf..."
                  />
                </div>

                <div>
                  <Label htmlFor="variant">Finition</Label>
                  <Input
                    id="variant"
                    value={formData.variant}
                    onChange={(e) => handleInputChange("variant", e.target.value)}
                    placeholder="Ex: GT Line, Zen, Carat..."
                  />
                </div>

                <div>
                  <Label htmlFor="year">Année *</Label>
                  <Input
                    id="year"
                    type="number"
                    value={formData.year}
                    onChange={(e) => handleInputChange("year", e.target.value)}
                    placeholder="2020"
                    min="1990"
                    max="2024"
                  />
                </div>

                <div>
                  <Label htmlFor="mileage">Kilométrage *</Label>
                  <Input
                    id="mileage"
                    type="number"
                    value={formData.mileage}
                    onChange={(e) => handleInputChange("mileage", e.target.value)}
                    placeholder="50000"
                  />
                </div>

                <div>
                  <Label htmlFor="price">Prix souhaité (€) *</Label>
                  <Input
                    id="price"
                    type="number"
                    value={formData.price}
                    onChange={(e) => handleInputChange("price", e.target.value)}
                    placeholder="15000"
                  />
                </div>

                <div>
                  <Label htmlFor="fuelType">Carburant *</Label>
                  <Select value={formData.fuelType} onValueChange={(value) => handleInputChange("fuelType", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Type de carburant" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="essence">Essence</SelectItem>
                      <SelectItem value="diesel">Diesel</SelectItem>
                      <SelectItem value="hybride">Hybride</SelectItem>
                      <SelectItem value="electrique">Électrique</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="transmission">Transmission *</Label>
                  <Select
                    value={formData.transmission}
                    onValueChange={(value) => handleInputChange("transmission", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Type de transmission" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manuelle">Manuelle</SelectItem>
                      <SelectItem value="automatique">Automatique</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end">
                <Button onClick={() => setStep(2)}>Suivant</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Step 2: Photos & Description */}
        <TabsContent value="2" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Photos et description</CardTitle>
              <CardDescription>Ajoutez des photos et décrivez votre véhicule</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Photo Upload */}
              <div>
                <Label>Photos du véhicule</Label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-2">Glissez vos photos ici ou cliquez pour sélectionner</p>
                  <p className="text-sm text-gray-500">Jusqu'à 10 photos - JPG, PNG (max 5MB chacune)</p>
                  <Button variant="outline" className="mt-4">
                    <Camera className="h-4 w-4 mr-2" />
                    Ajouter des photos
                  </Button>
                </div>
              </div>

              {/* Equipment */}
              <div>
                <Label>Équipements</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-2">
                  {availableFeatures.map((feature) => (
                    <div key={feature} className="flex items-center space-x-2">
                      <Checkbox
                        id={feature}
                        checked={formData.features.includes(feature)}
                        onCheckedChange={() => handleFeatureToggle(feature)}
                      />
                      <Label htmlFor={feature} className="text-sm">
                        {feature}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Description */}
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange("description", e.target.value)}
                  placeholder="Décrivez votre véhicule, son état, son historique..."
                  rows={6}
                  className="mt-2"
                />
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(1)}>
                  Précédent
                </Button>
                <Button onClick={() => setStep(3)}>Suivant</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Step 3: AI Optimization */}
        <TabsContent value="3" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-6 w-6 text-blue-600" />
                Optimisation IA
                <Sparkles className="h-4 w-4 text-purple-500" />
              </CardTitle>
              <CardDescription>L'IA analyse votre annonce et propose des améliorations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {!aiSuggestions ? (
                <div className="text-center py-8">
                  <Brain className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Optimisez votre annonce avec l'IA</h3>
                  <p className="text-gray-600 mb-6">
                    L'IA va analyser vos informations et proposer des améliorations pour maximiser vos chances de vente
                  </p>
                  <Button
                    onClick={optimizeWithAI}
                    disabled={aiOptimizing}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  >
                    {aiOptimizing ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Optimisation en cours...
                      </>
                    ) : (
                      <>
                        <Brain className="h-4 w-4 mr-2" />
                        Optimiser avec l'IA
                      </>
                    )}
                  </Button>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Title Suggestion */}
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-blue-900">Titre suggéré</h4>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => applySuggestion("title", aiSuggestions.titleSuggestion)}
                      >
                        Appliquer
                      </Button>
                    </div>
                    <p className="text-blue-800 text-sm">{aiSuggestions.titleSuggestion}</p>
                  </div>

                  {/* Description Suggestion */}
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-green-900">Description optimisée</h4>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => applySuggestion("description", aiSuggestions.descriptionSuggestion)}
                      >
                        Appliquer
                      </Button>
                    </div>
                    <p className="text-green-800 text-sm">{aiSuggestions.descriptionSuggestion}</p>
                  </div>

                  {/* Price Suggestion */}
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-yellow-900">Prix suggéré</h4>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => applySuggestion("price", aiSuggestions.priceSuggestion.toString())}
                      >
                        Appliquer
                      </Button>
                    </div>
                    <p className="text-yellow-800 text-sm">
                      {aiSuggestions.priceSuggestion.toLocaleString()}€
                      <span className="ml-2 text-xs">
                        (
                        {formData.price
                          ? Math.round(
                              ((aiSuggestions.priceSuggestion - Number.parseInt(formData.price)) /
                                Number.parseInt(formData.price)) *
                                100,
                            )
                          : 0}
                        % vs votre prix)
                      </span>
                    </p>
                  </div>

                  {/* Improvement Tips */}
                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                    <h4 className="font-medium text-purple-900 mb-2">Conseils d'amélioration</h4>
                    <ul className="space-y-1">
                      {aiSuggestions.improvementTips.map((tip, index) => (
                        <li key={index} className="text-purple-800 text-sm flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 text-purple-600 mt-0.5 flex-shrink-0" />
                          {tip}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(2)}>
                  Précédent
                </Button>
                <Button onClick={() => setStep(4)} disabled={!aiSuggestions}>
                  Suivant
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Step 4: Platform Selection */}
        <TabsContent value="4" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Diffusion multi-plateformes</CardTitle>
              <CardDescription>Choisissez où publier votre annonce pour maximiser sa visibilité</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {platforms.map((platform) => (
                  <Card
                    key={platform.id}
                    className={`cursor-pointer transition-all ${
                      formData.platforms.includes(platform.id) ? "ring-2 ring-blue-500 bg-blue-50" : ""
                    }`}
                    onClick={() => handlePlatformToggle(platform.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Checkbox checked={formData.platforms.includes(platform.id)} onChange={() => {}} />
                          <div>
                            <h4 className="font-medium">{platform.name}</h4>
                            {platform.popular && (
                              <Badge variant="secondary" className="text-xs mt-1">
                                Populaire
                              </Badge>
                            )}
                          </div>
                        </div>
                        <Share2 className="h-5 w-5 text-gray-400" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {formData.platforms.length > 0 && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h4 className="font-medium text-green-900 mb-2">Plateformes sélectionnées</h4>
                  <div className="flex flex-wrap gap-2">
                    {formData.platforms.map((platformId) => {
                      const platform = platforms.find((p) => p.id === platformId)
                      return (
                        <Badge key={platformId} variant="default">
                          {platform?.name}
                        </Badge>
                      )
                    })}
                  </div>
                  <p className="text-green-800 text-sm mt-2">
                    Votre annonce sera publiée simultanément sur {formData.platforms.length} plateforme
                    {formData.platforms.length > 1 ? "s" : ""}
                  </p>
                </div>
              )}

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(3)}>
                  Précédent
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={loading || formData.platforms.length === 0}
                  className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Publication en cours...
                    </>
                  ) : (
                    <>
                      <Share2 className="h-4 w-4 mr-2" />
                      Publier l'annonce
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
