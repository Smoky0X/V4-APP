"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { User, Mail, MapPin, Bell, Shield, Camera, Save, Loader2, CheckCircle, AlertCircle } from "lucide-react"
import { AuthService } from "@/lib/auth-service"
import type { User as UserType, AuthUser } from "@/types"

interface ProfileModalProps {
  isOpen: boolean
  onClose: () => void
  user: UserType
  authUser: AuthUser
  onUpdate: (updatedAuthUser: AuthUser, updatedUser: UserType) => void
}

export function ProfileModal({ isOpen, onClose, user, authUser, onUpdate }: ProfileModalProps) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  const [profileData, setProfileData] = useState({
    name: authUser.name,
    email: authUser.email,
    location: user.preferences.location,
    notifications: user.preferences.notifications,
  })

  const [preferencesData, setPreferencesData] = useState({
    budgetMin: user.preferences.budget.min,
    budgetMax: user.preferences.budget.max,
    usage: user.preferences.usage,
    fuelType: user.preferences.fuelType,
    categories: user.preferences.categories,
  })

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  const handleSaveProfile = async () => {
    setLoading(true)
    setError("")
    setSuccess("")

    try {
      const updatedAuthUser = await AuthService.updateProfile(authUser.id, {
        name: profileData.name,
        email: profileData.email,
      })

      const updatedUser: UserType = {
        ...user,
        name: profileData.name,
        email: profileData.email,
        preferences: {
          ...user.preferences,
          location: profileData.location,
          notifications: profileData.notifications,
        },
      }

      onUpdate(updatedAuthUser, updatedUser)
      setSuccess("Profil mis à jour avec succès !")
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur lors de la mise à jour")
    } finally {
      setLoading(false)
    }
  }

  const handleSavePreferences = async () => {
    setLoading(true)
    setError("")
    setSuccess("")

    try {
      const updatedUser: UserType = {
        ...user,
        preferences: {
          ...user.preferences,
          budget: {
            min: preferencesData.budgetMin,
            max: preferencesData.budgetMax,
          },
          usage: preferencesData.usage,
          fuelType: preferencesData.fuelType,
          categories: preferencesData.categories,
        },
      }

      onUpdate(authUser, updatedUser)
      setSuccess("Préférences mises à jour avec succès !")
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur lors de la mise à jour")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Mon profil</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="profile">Profil</TabsTrigger>
            <TabsTrigger value="preferences">Préférences</TabsTrigger>
            <TabsTrigger value="security">Sécurité</TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Informations personnelles</CardTitle>
                <CardDescription>Gérez vos informations de profil</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Avatar */}
                <div className="flex items-center gap-4">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={authUser.avatar || "/placeholder.svg"} alt={authUser.name} />
                    <AvatarFallback className="bg-gradient-to-r from-blue-600 to-purple-600 text-white text-xl">
                      {getInitials(authUser.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <Button variant="outline" size="sm">
                      <Camera className="h-4 w-4 mr-2" />
                      Changer la photo
                    </Button>
                    <p className="text-sm text-gray-500 mt-1">JPG, PNG ou GIF. Taille max 2MB.</p>
                  </div>
                </div>

                {/* Basic Info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Nom complet</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="name"
                        value={profileData.name}
                        onChange={(e) => setProfileData((prev) => ({ ...prev, name: e.target.value }))}
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="email">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="email"
                        type="email"
                        value={profileData.email}
                        onChange={(e) => setProfileData((prev) => ({ ...prev, email: e.target.value }))}
                        className="pl-10"
                      />
                    </div>
                    {!authUser.emailVerified && <p className="text-sm text-yellow-600 mt-1">⚠️ Email non vérifié</p>}
                  </div>

                  <div>
                    <Label htmlFor="location">Localisation</Label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="location"
                        value={profileData.location}
                        onChange={(e) => setProfileData((prev) => ({ ...prev, location: e.target.value }))}
                        placeholder="Ville, Code postal"
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div>
                    <Label>Type de compte</Label>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline">{user.type}</Badge>
                      <Badge className="bg-blue-500">{user.subscription}</Badge>
                    </div>
                  </div>
                </div>

                {/* Account Stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-blue-50 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {user.subscription === "gratuite" ? 3 - user.aiSearchesUsed : "∞"}
                    </div>
                    <div className="text-sm text-blue-600">Recherches IA</div>
                  </div>
                  <div className="bg-green-50 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-green-600">0</div>
                    <div className="text-sm text-green-600">Favoris</div>
                  </div>
                  <div className="bg-purple-50 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-purple-600">0</div>
                    <div className="text-sm text-purple-600">Comparaisons</div>
                  </div>
                  <div className="bg-orange-50 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-orange-600">
                      {Math.floor((Date.now() - authUser.createdAt.getTime()) / (1000 * 60 * 60 * 24))}
                    </div>
                    <div className="text-sm text-orange-600">Jours</div>
                  </div>
                </div>

                {/* Notifications */}
                <div className="space-y-4">
                  <h4 className="font-medium">Notifications</h4>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Bell className="h-4 w-4 text-gray-500" />
                      <span className="text-sm">Recevoir les notifications par email</span>
                    </div>
                    <Switch
                      checked={profileData.notifications}
                      onCheckedChange={(checked) => setProfileData((prev) => ({ ...prev, notifications: checked }))}
                    />
                  </div>
                </div>

                <Button onClick={handleSaveProfile} disabled={loading} className="w-full">
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Sauvegarde...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Sauvegarder
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Preferences Tab */}
          <TabsContent value="preferences" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Préférences de recherche</CardTitle>
                <CardDescription>Personnalisez vos critères de recherche par défaut</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Budget */}
                <div>
                  <Label>Budget (€)</Label>
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <div>
                      <Label htmlFor="budget-min" className="text-sm text-gray-600">
                        Minimum
                      </Label>
                      <Input
                        id="budget-min"
                        type="number"
                        value={preferencesData.budgetMin}
                        onChange={(e) =>
                          setPreferencesData((prev) => ({
                            ...prev,
                            budgetMin: Number.parseInt(e.target.value) || 0,
                          }))
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="budget-max" className="text-sm text-gray-600">
                        Maximum
                      </Label>
                      <Input
                        id="budget-max"
                        type="number"
                        value={preferencesData.budgetMax}
                        onChange={(e) =>
                          setPreferencesData((prev) => ({
                            ...prev,
                            budgetMax: Number.parseInt(e.target.value) || 0,
                          }))
                        }
                      />
                    </div>
                  </div>
                </div>

                {/* Usage */}
                <div>
                  <Label>Usage principal</Label>
                  <Select>
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Sélectionnez votre usage" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ville">Ville</SelectItem>
                      <SelectItem value="autoroute">Autoroute</SelectItem>
                      <SelectItem value="mixte">Mixte</SelectItem>
                      <SelectItem value="professionnel">Professionnel</SelectItem>
                      <SelectItem value="famille">Famille</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Fuel Type */}
                <div>
                  <Label>Types de carburant préférés</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {["Essence", "Diesel", "Hybride", "Électrique"].map((fuel) => (
                      <div key={fuel} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={fuel}
                          checked={preferencesData.fuelType.includes(fuel)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setPreferencesData((prev) => ({
                                ...prev,
                                fuelType: [...prev.fuelType, fuel],
                              }))
                            } else {
                              setPreferencesData((prev) => ({
                                ...prev,
                                fuelType: prev.fuelType.filter((f) => f !== fuel),
                              }))
                            }
                          }}
                          className="rounded"
                        />
                        <Label htmlFor={fuel} className="text-sm">
                          {fuel}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Categories */}
                <div>
                  <Label>Catégories préférées</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {["Citadine", "Compacte", "Berline", "SUV", "Break", "Coupé"].map((category) => (
                      <div key={category} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={category}
                          checked={preferencesData.categories.includes(category)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setPreferencesData((prev) => ({
                                ...prev,
                                categories: [...prev.categories, category],
                              }))
                            } else {
                              setPreferencesData((prev) => ({
                                ...prev,
                                categories: prev.categories.filter((c) => c !== category),
                              }))
                            }
                          }}
                          className="rounded"
                        />
                        <Label htmlFor={category} className="text-sm">
                          {category}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Button onClick={handleSavePreferences} disabled={loading} className="w-full">
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Sauvegarde...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Sauvegarder les préférences
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security Tab */}
          <TabsContent value="security" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Sécurité du compte</CardTitle>
                <CardDescription>Gérez la sécurité de votre compte</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Account Status */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Shield className="h-5 w-5 text-green-500" />
                      <div>
                        <p className="font-medium">Compte vérifié</p>
                        <p className="text-sm text-gray-600">Votre compte est sécurisé</p>
                      </div>
                    </div>
                    <Badge variant="secondary">Actif</Badge>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Mail className="h-5 w-5 text-yellow-500" />
                      <div>
                        <p className="font-medium">Vérification email</p>
                        <p className="text-sm text-gray-600">
                          {authUser.emailVerified ? "Email vérifié" : "Email non vérifié"}
                        </p>
                      </div>
                    </div>
                    <Badge variant={authUser.emailVerified ? "default" : "destructive"}>
                      {authUser.emailVerified ? "Vérifié" : "Non vérifié"}
                    </Badge>
                  </div>
                </div>

                {/* Change Password */}
                <div className="space-y-4">
                  <h4 className="font-medium">Changer le mot de passe</h4>
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="current-password">Mot de passe actuel</Label>
                      <Input id="current-password" type="password" />
                    </div>
                    <div>
                      <Label htmlFor="new-password">Nouveau mot de passe</Label>
                      <Input id="new-password" type="password" />
                    </div>
                    <div>
                      <Label htmlFor="confirm-password">Confirmer le nouveau mot de passe</Label>
                      <Input id="confirm-password" type="password" />
                    </div>
                  </div>
                  <Button variant="outline">Changer le mot de passe</Button>
                </div>

                {/* Account Info */}
                <div className="space-y-4">
                  <h4 className="font-medium">Informations du compte</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Créé le:</span>
                      <p className="font-medium">{authUser.createdAt.toLocaleDateString()}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Dernière connexion:</span>
                      <p className="font-medium">{authUser.lastLoginAt.toLocaleDateString()}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">ID utilisateur:</span>
                      <p className="font-medium font-mono">{authUser.id}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Type de compte:</span>
                      <p className="font-medium capitalize">{user.type}</p>
                    </div>
                  </div>
                </div>

                {/* Danger Zone */}
                <div className="border border-red-200 rounded-lg p-4 bg-red-50">
                  <h4 className="font-medium text-red-900 mb-2">Zone de danger</h4>
                  <p className="text-sm text-red-700 mb-4">Ces actions sont irréversibles. Procédez avec prudence.</p>
                  <div className="space-y-2">
                    <Button variant="outline" size="sm" className="text-red-600 border-red-200">
                      Désactiver le compte
                    </Button>
                    <Button variant="destructive" size="sm">
                      Supprimer le compte
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Messages */}
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="border-green-200 bg-green-50">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">{success}</AlertDescription>
          </Alert>
        )}
      </DialogContent>
    </Dialog>
  )
}
