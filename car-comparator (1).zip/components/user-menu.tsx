"use client"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { User, Settings, Crown, Heart, BarChart3, LogOut, Bell, CreditCard, HelpCircle } from "lucide-react"
import type { User as UserType, AuthUser } from "@/types"

interface UserMenuProps {
  user: UserType
  authUser: AuthUser
  onLogout: () => void
  onOpenProfile: () => void
  onOpenSubscription: () => void
}

export function UserMenu({ user, authUser, onLogout, onOpenProfile, onOpenSubscription }: UserMenuProps) {
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  const getSubscriptionColor = () => {
    switch (user.subscription) {
      case "premium":
      case "pro-plus":
        return "bg-blue-500"
      case "ultimate":
      case "pro-elite":
        return "bg-purple-500"
      case "pro-start":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-10 w-10 rounded-full">
          <Avatar className="h-10 w-10">
            <AvatarImage src={authUser.avatar || "/placeholder.svg"} alt={authUser.name} />
            <AvatarFallback className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
              {getInitials(authUser.name)}
            </AvatarFallback>
          </Avatar>
          {!authUser.emailVerified && (
            <div className="absolute -top-1 -right-1 h-3 w-3 bg-red-500 rounded-full border-2 border-white" />
          )}
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent className="w-80" align="end" forceMount>
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-2">
            <div className="flex items-center gap-3">
              <Avatar className="h-12 w-12">
                <AvatarImage src={authUser.avatar || "/placeholder.svg"} alt={authUser.name} />
                <AvatarFallback className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                  {getInitials(authUser.name)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <p className="text-sm font-medium leading-none">{authUser.name}</p>
                <p className="text-xs leading-none text-muted-foreground mt-1">{authUser.email}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="outline" className="text-xs">
                    {user.type}
                  </Badge>
                  <Badge className={`text-xs text-white ${getSubscriptionColor()}`}>{user.subscription}</Badge>
                </div>
              </div>
            </div>

            {!authUser.emailVerified && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-2">
                <p className="text-xs text-yellow-800">⚠️ Email non vérifié. Vérifiez votre boîte mail.</p>
              </div>
            )}

            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-blue-50 rounded-lg p-2">
                <div className="text-lg font-bold text-blue-600">
                  {user.subscription === "gratuite" ? 3 - user.aiSearchesUsed : "∞"}
                </div>
                <div className="text-xs text-blue-600">Recherches IA</div>
              </div>
              <div className="bg-green-50 rounded-lg p-2">
                <div className="text-lg font-bold text-green-600">0</div>
                <div className="text-xs text-green-600">Favoris</div>
              </div>
              <div className="bg-purple-50 rounded-lg p-2">
                <div className="text-lg font-bold text-purple-600">0</div>
                <div className="text-xs text-purple-600">Annonces</div>
              </div>
            </div>
          </div>
        </DropdownMenuLabel>

        <DropdownMenuSeparator />

        <DropdownMenuItem onClick={onOpenProfile}>
          <User className="mr-2 h-4 w-4" />
          <span>Mon profil</span>
        </DropdownMenuItem>

        <DropdownMenuItem>
          <Settings className="mr-2 h-4 w-4" />
          <span>Paramètres</span>
        </DropdownMenuItem>

        <DropdownMenuItem>
          <Bell className="mr-2 h-4 w-4" />
          <span>Notifications</span>
        </DropdownMenuItem>

        <DropdownMenuSeparator />

        <DropdownMenuItem>
          <Heart className="mr-2 h-4 w-4" />
          <span>Mes favoris</span>
        </DropdownMenuItem>

        <DropdownMenuItem>
          <BarChart3 className="mr-2 h-4 w-4" />
          <span>Mes recherches</span>
        </DropdownMenuItem>

        {user.type === "professionnel" && (
          <DropdownMenuItem>
            <CreditCard className="mr-2 h-4 w-4" />
            <span>Mes annonces</span>
          </DropdownMenuItem>
        )}

        <DropdownMenuSeparator />

        <DropdownMenuItem onClick={onOpenSubscription}>
          <Crown className="mr-2 h-4 w-4" />
          <span>Abonnement</span>
          {user.subscription === "gratuite" && (
            <Badge variant="secondary" className="ml-auto text-xs">
              Upgrade
            </Badge>
          )}
        </DropdownMenuItem>

        <DropdownMenuItem>
          <HelpCircle className="mr-2 h-4 w-4" />
          <span>Aide & Support</span>
        </DropdownMenuItem>

        <DropdownMenuSeparator />

        <DropdownMenuItem onClick={onLogout} className="text-red-600">
          <LogOut className="mr-2 h-4 w-4" />
          <span>Se déconnecter</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
