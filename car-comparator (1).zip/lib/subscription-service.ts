import type { Subscription } from "@/types"

export const subscriptionPlans: Record<string, Subscription> = {
  // Particuliers
  gratuite: {
    type: "gratuite",
    name: "Gratuite",
    price: 0,
    features: ["3 recherches IA/mois", "Comparateur classique", "Alertes de base"],
    aiSearches: 3,
    maxFavorites: 10,
    priceAlerts: true,
    marketAnalysis: false,
    chatbotAccess: false,
    multiPosting: false,
    crmAccess: false,
  },
  premium: {
    type: "premium",
    name: "Premium",
    price: 4.99,
    features: [
      "Recherches IA illimitées",
      "Recommandations IA avancées",
      "Suivi des baisses de prix",
      "Favoris synchronisés",
      "Analyse prédictive",
    ],
    aiSearches: -1,
    maxFavorites: 50,
    priceAlerts: true,
    marketAnalysis: true,
    chatbotAccess: true,
    multiPosting: false,
    crmAccess: false,
  },
  ultimate: {
    type: "ultimate",
    name: "Ultimate",
    price: 9.99,
    features: [
      "Toutes fonctions Premium",
      "Analyse prédictive avancée",
      "Chatbot IA dédié",
      "Classement qualité global",
      "Support prioritaire",
    ],
    aiSearches: -1,
    maxFavorites: -1,
    priceAlerts: true,
    marketAnalysis: true,
    chatbotAccess: true,
    multiPosting: false,
    crmAccess: false,
  },

  // Professionnels
  "pro-start": {
    type: "pro-start",
    name: "Pro Start",
    price: 19,
    features: ["Annonces illimitées", "Tableau de bord simplifié", "Estimation IA des véhicules"],
    aiSearches: -1,
    maxFavorites: -1,
    priceAlerts: true,
    marketAnalysis: true,
    chatbotAccess: false,
    multiPosting: false,
    crmAccess: false,
  },
  "pro-plus": {
    type: "pro-plus",
    name: "Pro Plus",
    price: 39,
    features: ["Multi-diffusion automatique", "Stats IA modèles populaires", "Conseils de pricing", "CRM basique"],
    aiSearches: -1,
    maxFavorites: -1,
    priceAlerts: true,
    marketAnalysis: true,
    chatbotAccess: true,
    multiPosting: true,
    crmAccess: true,
  },
  "pro-elite": {
    type: "pro-elite",
    name: "Pro Elite",
    price: 99,
    features: [
      "API dédiée",
      "Analyse marché temps réel",
      "Assistant IA intégré",
      "CRM automobile complet",
      "Support dédié",
    ],
    aiSearches: -1,
    maxFavorites: -1,
    priceAlerts: true,
    marketAnalysis: true,
    chatbotAccess: true,
    multiPosting: true,
    crmAccess: true,
  },
}

export class SubscriptionService {
  static canUseFeature(userSubscription: string, feature: string): boolean {
    const plan = subscriptionPlans[userSubscription]
    return plan?.features.some((f) => f.toLowerCase().includes(feature.toLowerCase())) || false
  }

  static getAISearchesLeft(user: any): number {
    const plan = subscriptionPlans[user.subscription]
    if (plan?.aiSearches === -1) return -1
    return Math.max(0, (plan?.aiSearches || 0) - user.aiSearchesUsed)
  }

  static canUseAI(user: any): boolean {
    const searchesLeft = this.getAISearchesLeft(user)
    return searchesLeft === -1 || searchesLeft > 0
  }
}
