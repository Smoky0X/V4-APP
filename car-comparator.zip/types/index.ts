export interface User {
  id: string
  email: string
  name: string
  type: "particulier" | "professionnel"
  subscription: "gratuite" | "premium" | "ultimate" | "pro-start" | "pro-plus" | "pro-elite"
  aiSearchesUsed: number
  createdAt: Date
  preferences: UserPreferences
}

export interface UserPreferences {
  budget: { min: number; max: number }
  usage: string[]
  fuelType: string[]
  categories: string[]
  location: string
  notifications: boolean
}

export interface Vehicle {
  id: string
  title: string
  brand: string
  model: string
  variant: string
  year: number
  price: number
  originalPrice?: number
  mileage: number
  fuelType: string
  transmission: string
  power: number
  consumption: number
  co2Emissions: number
  doors: number
  seats: number
  color: string
  category: string
  bodyType: string
  images: string[]
  description: string
  features: string[]
  location: string
  seller: Seller
  source: "leboncoin" | "lacentrale" | "autoscout24" | "carwize" | "facebook"

  // AI Ratings
  aiRating: number
  qualityPriceRatio: number
  reliabilityScore: number
  maintenanceCost: number
  resaleValue: number
  popularityScore: number

  // Market Analysis
  marketAnalysis: {
    priceEvolution: "increasing" | "decreasing" | "stable"
    recommendation: "buy_now" | "wait" | "overpriced" | "good_deal"
    confidence: number
  }

  createdAt: Date
  updatedAt: Date
}

export interface Seller {
  id: string
  name: string
  type: "particulier" | "professionnel"
  rating: number
  phone: string
  location: string
  verified: boolean
}

export interface AIRecommendation {
  vehicleId: string
  score: number
  reasons: string[]
  warnings: string[]
  financialAdvice: string
  negotiationTips: string[]
}

export interface Subscription {
  type: string
  name: string
  price: number
  features: string[]
  aiSearches: number
  maxFavorites: number
  priceAlerts: boolean
  marketAnalysis: boolean
  chatbotAccess: boolean
  multiPosting: boolean
  crmAccess: boolean
}

export interface SellListing {
  id: string
  userId: string
  vehicle: Vehicle
  status: "draft" | "active" | "sold" | "expired"
  platforms: string[]
  views: number
  contacts: number
  aiOptimizations: {
    titleSuggestion: string
    descriptionSuggestion: string
    priceSuggestion: number
    improvementTips: string[]
  }
}

export interface AuthUser {
  id: string
  email: string
  name: string
  avatar?: string
  emailVerified: boolean
  createdAt: Date
  lastLoginAt: Date
}

export interface LoginCredentials {
  email: string
  password: string
}

export interface SignupCredentials {
  name: string
  email: string
  password: string
  confirmPassword: string
  userType: "particulier" | "professionnel"
  acceptTerms: boolean
}
