"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Loader2, Brain, TrendingUp, AlertTriangle, DollarSign } from "lucide-react"
import { AICarAdvisor } from "@/lib/ai-service"
import type { UserPreferences, AIRecommendation } from "@/types"
import { carsDatabase } from "@/data/cars-database"

interface AIRecommendationsProps {
  preferences: UserPreferences
  userType: "particulier" | "professionnel"
  onCarSelect: (carId: string) => void
}

export function AIRecommendations({ preferences, userType, onCarSelect }: AIRecommendationsProps) {
  const [recommendations, setRecommendations] = useState<AIRecommendation[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const generateRecommendations = async () => {
    setLoading(true)
    setError(null)

    try {
      const recs = await AICarAdvisor.getPersonalizedRecommendations(preferences, carsDatabase, userType)
      setRecommendations(recs)
    } catch (err) {
      setError("Erreur lors de la génération des recommandations")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (preferences.budget.max > 0) {
      generateRecommendations()
    }
  }, [preferences, userType])

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
            <p>L'IA analyse vos critères...</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <AlertTriangle className="h-8 w-8 text-red-500 mx-auto mb-4" />
          <p className="text-red-600">{error}</p>
          <Button onClick={generateRecommendations} className="mt-4">
            Réessayer
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Brain className="h-6 w-6 text-blue-600" />
        <h2 className="text-2xl font-bold">Recommandations IA</h2>
        <Badge variant="secondary">{recommendations.length} véhicules analysés</Badge>
      </div>

      {recommendations.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <Brain className="h-8 w-8 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Aucune recommandation trouvée avec vos critères actuels</p>
            <p className="text-sm text-gray-500 mt-2">Essayez d'élargir votre budget ou vos critères de recherche</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6">
          {recommendations.map((rec) => {
            const car = carsDatabase.find((c) => c.id === rec.carId)!
            return (
              <Card key={rec.carId} className="overflow-hidden">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl">
                        {car.brand} {car.model} {car.variant}
                      </CardTitle>
                      <CardDescription className="text-lg font-semibold text-blue-600">
                        {car.price.toLocaleString()}€
                      </CardDescription>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="h-4 w-4 text-green-500" />
                        <span className="font-semibold">{Math.round(rec.score * 100)}% de compatibilité</span>
                      </div>
                      <Progress value={rec.score * 100} className="w-32" />
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <img
                        src={car.images[0] || "/placeholder.svg"}
                        alt={`${car.brand} ${car.model}`}
                        className="w-full h-48 object-cover rounded-lg"
                      />
                    </div>

                    <div className="space-y-4">
                      {rec.reasons.length > 0 && (
                        <div>
                          <h4 className="font-semibold text-green-700 mb-2">✅ Pourquoi ce véhicule vous correspond</h4>
                          <ul className="space-y-1">
                            {rec.reasons.map((reason, index) => (
                              <li key={index} className="text-sm text-green-600">
                                • {reason}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {rec.warnings.length > 0 && (
                        <div>
                          <h4 className="font-semibold text-orange-700 mb-2">⚠️ Points d'attention</h4>
                          <ul className="space-y-1">
                            {rec.warnings.map((warning, index) => (
                              <li key={index} className="text-sm text-orange-600">
                                • {warning}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <div className="bg-blue-50 p-3 rounded-lg">
                        <div className="flex items-start gap-2">
                          <DollarSign className="h-4 w-4 text-blue-600 mt-0.5" />
                          <div>
                            <h4 className="font-semibold text-blue-700 text-sm">Conseil financier IA</h4>
                            <p className="text-sm text-blue-600 mt-1">{rec.financialAdvice}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-4 border-t">
                    <div className="flex gap-2">
                      <Badge variant="outline">{car.category}</Badge>
                      <Badge variant="outline">{car.fuelType}</Badge>
                      <Badge variant="outline">⭐ {car.overallRating}/5</Badge>
                    </div>

                    <div className="flex gap-2">
                      <Button variant="outline" onClick={() => onCarSelect(car.id)}>
                        Voir détails
                      </Button>
                      <Button onClick={() => onCarSelect(car.id)}>Comparer</Button>
                    </div>
                  </div>

                  {rec.alternatives.length > 0 && (
                    <div className="text-sm text-gray-600">
                      <strong>Alternatives similaires:</strong> {rec.alternatives.join(", ")}
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
