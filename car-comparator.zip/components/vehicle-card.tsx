"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Heart,
  MapPin,
  Fuel,
  Gauge,
  Calendar,
  GaugeIcon as Speedometer,
  Star,
  TrendingUp,
  TrendingDown,
  Minus,
  Brain,
  Phone,
} from "lucide-react"
import type { Vehicle } from "@/types"

interface VehicleCardProps {
  vehicle: Vehicle
  onFavorite: (id: string) => void
  onCompare: (id: string) => void
  onViewDetails: (id: string) => void
  isFavorite: boolean
  isComparing: boolean
  showAIInsights?: boolean
}

export function VehicleCard({
  vehicle,
  onFavorite,
  onCompare,
  onViewDetails,
  isFavorite,
  isComparing,
  showAIInsights = false,
}: VehicleCardProps) {
  const [imageError, setImageError] = useState(false)

  const getPriceEvolutionIcon = () => {
    switch (vehicle.marketAnalysis.priceEvolution) {
      case "increasing":
        return <TrendingUp className="h-4 w-4 text-red-500" />
      case "decreasing":
        return <TrendingDown className="h-4 w-4 text-green-500" />
      default:
        return <Minus className="h-4 w-4 text-gray-500" />
    }
  }

  const getRecommendationColor = () => {
    switch (vehicle.marketAnalysis.recommendation) {
      case "good_deal":
        return "bg-green-500"
      case "buy_now":
        return "bg-blue-500"
      case "wait":
        return "bg-yellow-500"
      case "overpriced":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <Card className="hover:shadow-lg transition-all duration-300 group">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <CardTitle className="text-lg line-clamp-1">{vehicle.title}</CardTitle>
            <CardDescription className="flex items-center gap-2 mt-1">
              <Calendar className="h-3 w-3" />
              {vehicle.year}
              <Speedometer className="h-3 w-3 ml-2" />
              {vehicle.mileage.toLocaleString()} km
              <MapPin className="h-3 w-3 ml-2" />
              {vehicle.location}
            </CardDescription>
          </div>

          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onFavorite(vehicle.id)}
              className="text-red-500 hover:text-red-600"
            >
              <Heart className={`h-4 w-4 ${isFavorite ? "fill-current" : ""}`} />
            </Button>

            <Badge variant="outline" className="text-xs">
              {vehicle.source}
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Image */}
        <div className="relative">
          <img
            src={imageError ? "/placeholder.svg?height=200&width=300" : vehicle.images[0]}
            alt={vehicle.title}
            className="w-full h-48 object-cover rounded-lg cursor-pointer"
            onClick={() => onViewDetails(vehicle.id)}
            onError={() => setImageError(true)}
          />

          {/* AI Rating Overlay */}
          <div className="absolute top-2 left-2 bg-black/70 text-white px-2 py-1 rounded-lg text-sm font-medium">
            <div className="flex items-center gap-1">
              <Brain className="h-3 w-3" />
              {vehicle.aiRating}/10
            </div>
          </div>

          {/* Price Evolution */}
          <div className="absolute top-2 right-2 bg-white/90 px-2 py-1 rounded-lg">{getPriceEvolutionIcon()}</div>

          {/* Discount Badge */}
          {vehicle.originalPrice && vehicle.originalPrice > vehicle.price && (
            <div className="absolute bottom-2 left-2 bg-red-500 text-white px-2 py-1 rounded-lg text-sm font-medium">
              -{Math.round(((vehicle.originalPrice - vehicle.price) / vehicle.originalPrice) * 100)}%
            </div>
          )}
        </div>

        {/* Price */}
        <div className="flex justify-between items-center">
          <div>
            <div className="text-2xl font-bold text-blue-600">{vehicle.price.toLocaleString()} €</div>
            {vehicle.originalPrice && vehicle.originalPrice > vehicle.price && (
              <div className="text-sm text-gray-500 line-through">{vehicle.originalPrice.toLocaleString()} €</div>
            )}
          </div>

          <div className="text-right">
            <div className="flex items-center gap-1 mb-1">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span className="text-sm font-medium">{vehicle.seller.rating}</span>
            </div>
            <Badge variant={vehicle.seller.verified ? "default" : "secondary"} className="text-xs">
              {vehicle.seller.verified ? "Vérifié" : "Non vérifié"}
            </Badge>
          </div>
        </div>

        {/* Vehicle specs */}
        <div className="grid grid-cols-3 gap-2 text-sm">
          <div className="flex items-center gap-1">
            <Fuel className="h-4 w-4 text-gray-500" />
            <span>{vehicle.fuelType}</span>
          </div>
          <div className="flex items-center gap-1">
            <Gauge className="h-4 w-4 text-gray-500" />
            <span>{vehicle.power} ch</span>
          </div>
          <div className="text-center">
            <span>{vehicle.consumption}L/100km</span>
          </div>
        </div>

        {/* AI Insights */}
        {showAIInsights && (
          <div className="space-y-2">
            <div className="text-sm font-medium text-gray-700">Analyse IA :</div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <div className="flex justify-between">
                  <span>Qualité/Prix</span>
                  <span>{vehicle.qualityPriceRatio}/10</span>
                </div>
                <Progress value={vehicle.qualityPriceRatio * 10} className="h-1" />
              </div>

              <div>
                <div className="flex justify-between">
                  <span>Fiabilité</span>
                  <span>{vehicle.reliabilityScore}/10</span>
                </div>
                <Progress value={vehicle.reliabilityScore * 10} className="h-1" />
              </div>
            </div>

            <div className={`text-xs px-2 py-1 rounded text-white ${getRecommendationColor()}`}>
              {vehicle.marketAnalysis.recommendation === "good_deal" && "🎯 Bonne affaire"}
              {vehicle.marketAnalysis.recommendation === "buy_now" && "⚡ Achetez maintenant"}
              {vehicle.marketAnalysis.recommendation === "wait" && "⏳ Attendez"}
              {vehicle.marketAnalysis.recommendation === "overpriced" && "💸 Trop cher"}
            </div>
          </div>
        )}

        {/* Seller info */}
        <div className="flex items-center justify-between text-sm text-gray-600">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-gray-300 rounded-full flex items-center justify-center text-xs">
              {vehicle.seller.name.charAt(0)}
            </div>
            <span>{vehicle.seller.name}</span>
            <Badge variant="outline" className="text-xs">
              {vehicle.seller.type}
            </Badge>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Button
            variant={isComparing ? "default" : "outline"}
            size="sm"
            onClick={() => onCompare(vehicle.id)}
            className="flex-1"
          >
            {isComparing ? "✓ Comparé" : "Comparer"}
          </Button>

          <Button variant="outline" size="sm" onClick={() => onViewDetails(vehicle.id)}>
            Détails
          </Button>

          <Button size="sm" className="bg-green-600 hover:bg-green-700">
            <Phone className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
