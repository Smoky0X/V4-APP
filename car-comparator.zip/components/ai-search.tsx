"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Loader2, Brain, Sparkles, MessageSquare } from "lucide-react"
import { CarWizeAI } from "@/lib/ai-service"
import { SubscriptionService } from "@/lib/subscription-service"
import type { Vehicle, User } from "@/types"

interface AISearchProps {
  user: User | null
  onResults: (vehicles: Vehicle[]) => void
  onUpgradeNeeded: () => void
}

export function AISearch({ user, onResults, onUpgradeNeeded }: AISearchProps) {
  const [query, setQuery] = useState("")
  const [loading, setLoading] = useState(false)
  const [lastQuery, setLastQuery] = useState("")

  const canUseAI = user && SubscriptionService.canUseAI(user)
  const searchesLeft = user ? SubscriptionService.getAISearchesLeft(user) : 0

  const handleSearch = async () => {
    if (!user) return
    if (!canUseAI) {
      onUpgradeNeeded()
      return
    }

    setLoading(true)
    setLastQuery(query)

    try {
      const results = await CarWizeAI.searchWithNaturalLanguage(query, user)
      onResults(results)

      // Update user's AI searches used
      if (searchesLeft !== -1) {
        // In real app, this would update the database
        user.aiSearchesUsed += 1
      }
    } catch (error) {
      console.error("AI search failed:", error)
    } finally {
      setLoading(false)
    }
  }

  const exampleQueries = [
    "Une voiture fiable pour moins de 15 000€, pas trop vieille",
    "SUV familial hybride avec 7 places",
    "Citadine économique pour jeune conducteur",
    "Berline allemande premium d'occasion",
  ]

  return (
    <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-purple-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-6 w-6 text-blue-600" />
          Recherche IA CarWize
          <Sparkles className="h-4 w-4 text-purple-500" />
        </CardTitle>
        <CardDescription>Décrivez simplement ce que vous cherchez, l'IA trouve les meilleures options</CardDescription>

        {user && (
          <div className="flex items-center gap-2">
            <Badge variant={canUseAI ? "default" : "destructive"}>
              {searchesLeft === -1 ? "Illimité" : `${searchesLeft} recherches restantes`}
            </Badge>
            <Badge variant="outline">{user.subscription}</Badge>
          </div>
        )}
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Ex: Je cherche une voiture fiable pour moins de 10 000€..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSearch()}
            className="flex-1"
            disabled={loading}
          />
          <Button
            onClick={handleSearch}
            disabled={loading || !query.trim() || !canUseAI}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <MessageSquare className="h-4 w-4" />}
            {loading ? "Recherche..." : "Rechercher"}
          </Button>
        </div>

        {!canUseAI && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
            <p className="text-sm text-yellow-800">
              🔒 Recherche IA disponible avec les abonnements Premium et Ultimate
            </p>
          </div>
        )}

        <div className="space-y-2">
          <p className="text-sm font-medium text-gray-700">Exemples de recherches :</p>
          <div className="flex flex-wrap gap-2">
            {exampleQueries.map((example, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => setQuery(example)}
                className="text-xs h-auto py-1 px-2"
                disabled={loading}
              >
                {example}
              </Button>
            ))}
          </div>
        </div>

        {lastQuery && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <p className="text-sm text-blue-800">
              <strong>Dernière recherche :</strong> "{lastQuery}"
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
