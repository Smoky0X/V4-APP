"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import {
  CarIcon,
  Users,
  Building2,
  Brain,
  Crown,
  Settings,
  BarChart3,
  Search,
  Heart,
  ContrastIcon as Compare,
  Plus,
  TrendingUp,
  Shield,
  Zap,
  Target,
  LogIn,
} from "lucide-react"

import { AISearch } from "@/components/ai-search"
import { VehicleCard } from "@/components/vehicle-card"
import { SubscriptionModal } from "@/components/subscription-modal"
import { SellVehicleForm } from "@/components/sell-vehicle-form"
import { Chatbot } from "@/components/chatbot"
import { AuthModal } from "@/components/auth/login-modal"
import { UserMenu } from "@/components/user-menu"
import { ProfileModal } from "@/components/profile-modal"
import { SubscriptionService } from "@/lib/subscription-service"
import { AuthService } from "@/lib/auth-service"
import type { Vehicle, User, AuthUser } from "@/types"

// Mock data (same as before)
const mockVehicles: Vehicle[] = [
  {
    id: "1",
    title: "Peugeot 208 GT Line 1.2 PureTech 100ch",
    brand: "Peugeot",
    model: "208",
    variant: "GT Line",
    year: 2022,
    price: 18500,
    originalPrice: 19500,
    mileage: 25000,
    fuelType: "Essence",
    transmission: "Manuelle",
    power: 100,
    consumption: 5.2,
    co2Emissions: 118,
    doors: 5,
    seats: 5,
    color: "Blanc",
    category: "Citadine",
    bodyType: "Berline",
    images: ["/placeholder.svg?height=300&width=400"],
    description: "Peugeot 208 en excellent état, première main, carnet d'entretien suivi.",
    features: ["Climatisation", "GPS", "Bluetooth", "Régulateur de vitesse"],
    location: "Paris (75)",
    seller: {
      id: "s1",
      name: "Jean Dupont",
      type: "particulier",
      rating: 4.8,
      phone: "06 12 34 56 78",
      location: "Paris",
      verified: true,
    },
    source: "leboncoin",
    aiRating: 8.7,
    qualityPriceRatio: 8.5,
    reliabilityScore: 8.2,
    maintenanceCost: 6.5,
    resaleValue: 7.8,
    popularityScore: 9.1,
    marketAnalysis: {
      priceEvolution: "stable",
      recommendation: "good_deal",
      confidence: 0.87,
    },
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: "2",
    title: "Renault Clio V Zen TCe 90",
    brand: "Renault",
    model: "Clio",
    variant: "Zen",
    year: 2021,
    price: 16800,
    mileage: 32000,
    fuelType: "Essence",
    transmission: "Manuelle",
    power: 90,
    consumption: 5.4,
    co2Emissions: 123,
    doors: 5,
    seats: 5,
    color: "Gris",
    category: "Citadine",
    bodyType: "Berline",
    images: ["/placeholder.svg?height=300&width=400"],
    description: "Renault Clio récente, très bien entretenue, garantie constructeur.",
    features: ["Climatisation", "Bluetooth", "Aide au stationnement"],
    location: "Lyon (69)",
    seller: {
      id: "s2",
      name: "Garage Martin",
      type: "professionnel",
      rating: 4.6,
      phone: "04 78 12 34 56",
      location: "Lyon",
      verified: true,
    },
    source: "lacentrale",
    aiRating: 8.1,
    qualityPriceRatio: 8.8,
    reliabilityScore: 8.5,
    maintenanceCost: 5.8,
    resaleValue: 8.2,
    popularityScore: 8.9,
    marketAnalysis: {
      priceEvolution: "decreasing",
      recommendation: "buy_now",
      confidence: 0.92,
    },
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: "3",
    title: "Tesla Model 3 Long Range AWD",
    brand: "Tesla",
    model: "Model 3",
    variant: "Long Range",
    year: 2023,
    price: 52000,
    mileage: 15000,
    fuelType: "Électrique",
    transmission: "Automatique",
    power: 351,
    consumption: 0,
    co2Emissions: 0,
    doors: 4,
    seats: 5,
    color: "Noir",
    category: "Berline",
    bodyType: "Berline",
    images: ["/placeholder.svg?height=300&width=400"],
    description: "Tesla Model 3 comme neuve, autopilot, supercharger inclus.",
    features: ["Autopilot", 'Écran tactile 15"', "Toit panoramique", "Sièges chauffants"],
    location: "Marseille (13)",
    seller: {
      id: "s3",
      name: "Pierre Électrique",
      type: "particulier",
      rating: 4.9,
      phone: "04 91 23 45 67",
      location: "Marseille",
      verified: true,
    },
    source: "autoscout24",
    aiRating: 9.2,
    qualityPriceRatio: 7.8,
    reliabilityScore: 8.8,
    maintenanceCost: 3.2,
    resaleValue: 9.1,
    popularityScore: 9.5,
    marketAnalysis: {
      priceEvolution: "increasing",
      recommendation: "good_deal",
      confidence: 0.78,
    },
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

export default function Page() {
  // Auth state
  const [authUser, setAuthUser] = useState<AuthUser | null>(null)
  const [user, setUser] = useState<User | null>(null)
  const [userType, setUserType] = useState<"particulier" | "professionnel" | null>(null)
  const [authToken, setAuthToken] = useState<string | null>(null)

  // Modals
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false)
  const [showProfileModal, setShowProfileModal] = useState(false)

  // App state
  const [currentView, setCurrentView] = useState<"home" | "search" | "sell">("home")
  const [vehicles, setVehicles] = useState<Vehicle[]>(mockVehicles)
  const [filteredVehicles, setFilteredVehicles] = useState<Vehicle[]>(mockVehicles)
  const [favorites, setFavorites] = useState<string[]>([])
  const [comparing, setComparing] = useState<string[]>([])

  // Filters
  const [filters, setFilters] = useState({
    search: "",
    brand: "",
    category: "",
    fuelType: "",
    priceRange: [0, 100000] as [number, number],
    yearRange: [2010, 2024] as [number, number],
    mileageMax: 200000,
    minRating: 0,
  })

  // Check for existing session on mount
  useEffect(() => {
    const token = localStorage.getItem("carwize_token")
    const savedUserType = localStorage.getItem("carwize_user_type") as "particulier" | "professionnel" | null

    if (token && savedUserType) {
      AuthService.getCurrentUser(token).then((authUser) => {
        if (authUser) {
          setAuthUser(authUser)
          setAuthToken(token)
          setUserType(savedUserType)

          const fullUser = AuthService.createFullUser(authUser, savedUserType)
          setUser(fullUser)
        } else {
          // Invalid token, clear storage
          localStorage.removeItem("carwize_token")
          localStorage.removeItem("carwize_user_type")
        }
      })
    }
  }, [])

  // Filter vehicles
  useEffect(() => {
    let filtered = vehicles

    if (filters.search) {
      filtered = filtered.filter(
        (v) =>
          v.title.toLowerCase().includes(filters.search.toLowerCase()) ||
          v.brand.toLowerCase().includes(filters.search.toLowerCase()) ||
          v.model.toLowerCase().includes(filters.search.toLowerCase()),
      )
    }

    if (filters.brand && filters.brand !== "all") {
      filtered = filtered.filter((v) => v.brand === filters.brand)
    }

    if (filters.category && filters.category !== "all") {
      filtered = filtered.filter((v) => v.category === filters.category)
    }

    if (filters.fuelType && filters.fuelType !== "all") {
      filtered = filtered.filter((v) => v.fuelType === filters.fuelType)
    }

    filtered = filtered.filter((v) => v.price >= filters.priceRange[0] && v.price <= filters.priceRange[1])
    filtered = filtered.filter((v) => v.year >= filters.yearRange[0] && v.year <= filters.yearRange[1])

    if (filters.mileageMax < 200000) {
      filtered = filtered.filter((v) => v.mileage <= filters.mileageMax)
    }

    if (filters.minRating > 0) {
      filtered = filtered.filter((v) => v.aiRating >= filters.minRating)
    }

    setFilteredVehicles(filtered)
  }, [vehicles, filters])

  const handleAuthSuccess = (newAuthUser: AuthUser, newUserType: "particulier" | "professionnel") => {
    setAuthUser(newAuthUser)
    setUserType(newUserType)

    const fullUser = AuthService.createFullUser(newAuthUser, newUserType)
    setUser(fullUser)

    // Save to localStorage
    const token = `token_${newAuthUser.id}_${Date.now()}`
    setAuthToken(token)
    localStorage.setItem("carwize_token", token)
    localStorage.setItem("carwize_user_type", newUserType)
  }

  const handleLogout = async () => {
    try {
      if (authToken) {
        await AuthService.logout()
      }
    } finally {
      setAuthUser(null)
      setUser(null)
      setUserType(null)
      setAuthToken(null)
      localStorage.removeItem("carwize_token")
      localStorage.removeItem("carwize_user_type")
    }
  }

  const handleProfileUpdate = (updatedAuthUser: AuthUser, updatedUser: User) => {
    setAuthUser(updatedAuthUser)
    setUser(updatedUser)
  }

  const handleFavorite = (vehicleId: string) => {
    if (!user) {
      setShowAuthModal(true)
      return
    }
    setFavorites((prev) => (prev.includes(vehicleId) ? prev.filter((id) => id !== vehicleId) : [...prev, vehicleId]))
  }

  const handleCompare = (vehicleId: string) => {
    if (!user) {
      setShowAuthModal(true)
      return
    }

    setComparing((prev) => {
      if (prev.includes(vehicleId)) {
        return prev.filter((id) => id !== vehicleId)
      } else if (prev.length < 3) {
        return [...prev, vehicleId]
      } else {
        if (user.subscription === "gratuite") {
          setShowSubscriptionModal(true)
        }
        return prev
      }
    })
  }

  const handleAISearchResults = (results: Vehicle[]) => {
    setVehicles(results)
    setCurrentView("search")
  }

  const handleUpgrade = (plan: string) => {
    if (user) {
      setUser({ ...user, subscription: plan as any })
    }
  }

  const handleSellSubmit = (listing: any) => {
    console.log("Listing submitted:", listing)
    setCurrentView("search")
  }

  // Landing page for non-authenticated users
  if (!authUser || !userType) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <div className="container mx-auto px-4 py-16">
          {/* Header */}
          <div className="flex justify-between items-center mb-16">
            <div className="flex items-center gap-2">
              <CarIcon className="h-8 w-8 text-blue-600" />
              <Brain className="h-5 w-5 text-purple-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                CarWize AI
              </span>
            </div>
            <Button onClick={() => setShowAuthModal(true)} className="bg-gradient-to-r from-blue-600 to-purple-600">
              <LogIn className="h-4 w-4 mr-2" />
              Se connecter
            </Button>
          </div>

          {/* Hero Section */}
          <div className="text-center mb-16">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <CarIcon className="h-20 w-20 text-blue-600" />
                <Brain className="h-8 w-8 text-purple-600 absolute -top-2 -right-2 bg-white rounded-full p-1" />
              </div>
            </div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-6">
              CarWize AI
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              La première plateforme automobile intelligente propulsée par l'IA. Trouvez, comparez et vendez des
              véhicules avec des recommandations personnalisées.
            </p>

            <div className="flex justify-center gap-6 mb-12">
              <Badge variant="secondary" className="text-sm py-2 px-4">
                <Brain className="h-4 w-4 mr-2" />
                IA Avancée
              </Badge>
              <Badge variant="secondary" className="text-sm py-2 px-4">
                <BarChart3 className="h-4 w-4 mr-2" />
                Analytics Pro
              </Badge>
              <Badge variant="secondary" className="text-sm py-2 px-4">
                <Target className="h-4 w-4 mr-2" />
                Recommandations
              </Badge>
              <Badge variant="secondary" className="text-sm py-2 px-4">
                <Shield className="h-4 w-4 mr-2" />
                Sécurisé
              </Badge>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card
              className="cursor-pointer hover:shadow-2xl transition-all duration-300 border-2 hover:border-blue-500 hover:scale-105 group"
              onClick={() => {
                setUserType("particulier")
                setShowAuthModal(true)
              }}
            >
              <CardHeader className="text-center pb-4">
                <div className="flex justify-center mb-4">
                  <div className="p-4 bg-blue-100 rounded-full group-hover:bg-blue-200 transition-colors">
                    <Users className="h-12 w-12 text-blue-600" />
                  </div>
                </div>
                <CardTitle className="text-2xl mb-2">Particulier</CardTitle>
                <CardDescription className="text-lg">
                  Solutions personnalisées pour votre véhicule personnel
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-center gap-3">
                    <Brain className="h-5 w-5 text-blue-500" />
                    <span>Conseils IA personnalisés</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <BarChart3 className="h-5 w-5 text-green-500" />
                    <span>Analyse coût/bénéfice</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Heart className="h-5 w-5 text-red-500" />
                    <span>Recommandations familiales</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <TrendingUp className="h-5 w-5 text-purple-500" />
                    <span>Suivi des prix en temps réel</span>
                  </li>
                </ul>

                <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                  <p className="text-sm text-blue-800 font-medium">🎯 Parfait pour trouver votre prochaine voiture</p>
                </div>
              </CardContent>
            </Card>

            <Card
              className="cursor-pointer hover:shadow-2xl transition-all duration-300 border-2 hover:border-green-500 hover:scale-105 group"
              onClick={() => {
                setUserType("professionnel")
                setShowAuthModal(true)
              }}
            >
              <CardHeader className="text-center pb-4">
                <div className="flex justify-center mb-4">
                  <div className="p-4 bg-green-100 rounded-full group-hover:bg-green-200 transition-colors">
                    <Building2 className="h-12 w-12 text-green-600" />
                  </div>
                </div>
                <CardTitle className="text-2xl mb-2">Professionnel</CardTitle>
                <CardDescription className="text-lg">Gestion de flotte et optimisation business</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-center gap-3">
                    <Crown className="h-5 w-5 text-purple-500" />
                    <span>Optimisation fiscale avancée</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <BarChart3 className="h-5 w-5 text-blue-500" />
                    <span>Analytics de flotte</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Settings className="h-5 w-5 text-gray-500" />
                    <span>Multi-diffusion automatique</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Zap className="h-5 w-5 text-yellow-500" />
                    <span>CRM automobile intégré</span>
                  </li>
                </ul>

                <div className="mt-6 p-4 bg-green-50 rounded-lg">
                  <p className="text-sm text-green-800 font-medium">🚀 Idéal pour les professionnels de l'automobile</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-16">
            <p className="text-gray-600 mb-4">Déjà utilisé par plus de 50 000 utilisateurs</p>
            <div className="flex justify-center gap-8 text-sm text-gray-500">
              <span>⭐ 4.8/5 sur les stores</span>
              <span>🔒 100% sécurisé</span>
              <span>🇫🇷 Made in France</span>
            </div>
          </div>
        </div>

        {/* Auth Modal */}
        <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} onSuccess={handleAuthSuccess} />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <CarIcon className="h-8 w-8 text-blue-600" />
                <Brain className="h-5 w-5 text-purple-600" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                CarWize AI
              </h1>
              <Badge variant={userType === "particulier" ? "default" : "secondary"}>
                {userType === "particulier" ? "Particulier" : "Professionnel"}
              </Badge>
              {user && (
                <Badge
                  variant={user.subscription === "gratuite" ? "outline" : "default"}
                  className={
                    user.subscription === "ultimate" || user.subscription === "pro-elite"
                      ? "bg-purple-500"
                      : user.subscription.includes("premium") || user.subscription.includes("pro")
                        ? "bg-blue-500"
                        : ""
                  }
                >
                  {user.subscription === "gratuite" && "🆓 Gratuit"}
                  {user.subscription === "premium" && "👑 Premium"}
                  {user.subscription === "ultimate" && "⚡ Ultimate"}
                  {user.subscription.includes("pro") && "🏢 Pro"}
                </Badge>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant={currentView === "search" ? "default" : "outline"}
                onClick={() => setCurrentView("search")}
              >
                <Search className="h-4 w-4 mr-2" />
                Rechercher
              </Button>

              <Button variant={currentView === "sell" ? "default" : "outline"} onClick={() => setCurrentView("sell")}>
                <Plus className="h-4 w-4 mr-2" />
                Vendre
              </Button>

              {authUser && user && (
                <UserMenu
                  user={user}
                  authUser={authUser}
                  onLogout={handleLogout}
                  onOpenProfile={() => setShowProfileModal(true)}
                  onOpenSubscription={() => setShowSubscriptionModal(true)}
                />
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {currentView === "home" && (
          <div className="space-y-8">
            {/* AI Search */}
            <AISearch
              user={user}
              onResults={handleAISearchResults}
              onUpgradeNeeded={() => setShowSubscriptionModal(true)}
            />

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">{vehicles.length.toLocaleString()}</div>
                  <p className="text-sm text-gray-600">Véhicules disponibles</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-green-600 mb-2">{favorites.length}</div>
                  <p className="text-sm text-gray-600">Favoris</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-purple-600 mb-2">{comparing.length}/3</div>
                  <p className="text-sm text-gray-600">En comparaison</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-orange-600 mb-2">
                    {user
                      ? SubscriptionService.getAISearchesLeft(user) === -1
                        ? "∞"
                        : SubscriptionService.getAISearchesLeft(user)
                      : 0}
                  </div>
                  <p className="text-sm text-gray-600">Recherches IA</p>
                </CardContent>
              </Card>
            </div>

            {/* Featured Vehicles */}
            <div>
              <h2 className="text-2xl font-bold mb-6">Véhicules recommandés</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {vehicles.slice(0, 6).map((vehicle) => (
                  <VehicleCard
                    key={vehicle.id}
                    vehicle={vehicle}
                    onFavorite={handleFavorite}
                    onCompare={handleCompare}
                    onViewDetails={(id) => console.log("View details:", id)}
                    isFavorite={favorites.includes(vehicle.id)}
                    isComparing={comparing.includes(vehicle.id)}
                    showAIInsights={user?.subscription !== "gratuite"}
                  />
                ))}
              </div>
            </div>
          </div>
        )}

        {currentView === "search" && (
          <div className="space-y-6">
            {/* Filters */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="h-5 w-5" />
                  Recherche avancée
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
                  <Input
                    placeholder="Rechercher..."
                    value={filters.search}
                    onChange={(e) => setFilters((prev) => ({ ...prev, search: e.target.value }))}
                  />

                  <Select
                    value={filters.brand}
                    onValueChange={(value) => setFilters((prev) => ({ ...prev, brand: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Marque" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes</SelectItem>
                      <SelectItem value="Peugeot">Peugeot</SelectItem>
                      <SelectItem value="Renault">Renault</SelectItem>
                      <SelectItem value="Tesla">Tesla</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select
                    value={filters.category}
                    onValueChange={(value) => setFilters((prev) => ({ ...prev, category: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Catégorie" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes</SelectItem>
                      <SelectItem value="Citadine">Citadine</SelectItem>
                      <SelectItem value="Berline">Berline</SelectItem>
                      <SelectItem value="SUV">SUV</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select
                    value={filters.fuelType}
                    onValueChange={(value) => setFilters((prev) => ({ ...prev, fuelType: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Carburant" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="Essence">Essence</SelectItem>
                      <SelectItem value="Diesel">Diesel</SelectItem>
                      <SelectItem value="Électrique">Électrique</SelectItem>
                    </SelectContent>
                  </Select>

                  <div className="col-span-2">
                    <label className="text-sm font-medium mb-2 block">
                      Prix: {filters.priceRange[0].toLocaleString()}€ - {filters.priceRange[1].toLocaleString()}€
                    </label>
                    <Slider
                      value={filters.priceRange}
                      onValueChange={(value) =>
                        setFilters((prev) => ({ ...prev, priceRange: value as [number, number] }))
                      }
                      max={100000}
                      min={0}
                      step={1000}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Results */}
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">
                {filteredVehicles.length} véhicule{filteredVehicles.length > 1 ? "s" : ""} trouvé
                {filteredVehicles.length > 1 ? "s" : ""}
              </h2>

              {comparing.length > 0 && (
                <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                  <Compare className="h-4 w-4 mr-2" />
                  Comparer ({comparing.length})
                </Button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredVehicles.map((vehicle) => (
                <VehicleCard
                  key={vehicle.id}
                  vehicle={vehicle}
                  onFavorite={handleFavorite}
                  onCompare={handleCompare}
                  onViewDetails={(id) => console.log("View details:", id)}
                  isFavorite={favorites.includes(vehicle.id)}
                  isComparing={comparing.includes(vehicle.id)}
                  showAIInsights={user?.subscription !== "gratuite"}
                />
              ))}
            </div>
          </div>
        )}

        {currentView === "sell" && <SellVehicleForm user={user} onSubmit={handleSellSubmit} />}
      </div>

      {/* Modals */}
      <SubscriptionModal
        isOpen={showSubscriptionModal}
        onClose={() => setShowSubscriptionModal(false)}
        currentPlan={user?.subscription || "gratuite"}
        userType={userType || "particulier"}
        onUpgrade={handleUpgrade}
      />

      {authUser && user && (
        <ProfileModal
          isOpen={showProfileModal}
          onClose={() => setShowProfileModal(false)}
          user={user}
          authUser={authUser}
          onUpdate={handleProfileUpdate}
        />
      )}

      {/* Chatbot */}
      <Chatbot user={user} />
    </div>
  )
}
