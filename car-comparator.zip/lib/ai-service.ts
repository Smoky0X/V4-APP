import type { Vehicle, UserPreferences, AIRecommendation, User } from "@/types"

export class CarWizeAI {
  static async searchWithNaturalLanguage(query: string, user: User): Promise<Vehicle[]> {
    // Simulate AI processing
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Parse natural language query
    const parsedQuery = this.parseNaturalLanguage(query)

    // Return filtered vehicles based on AI understanding
    return this.getVehiclesFromQuery(parsedQuery)
  }

  static async getPersonalizedRecommendations(
    preferences: UserPreferences,
    vehicles: Vehicle[],
    userType: "particulier" | "professionnel",
  ): Promise<AIRecommendation[]> {
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const recommendations: AIRecommendation[] = []

    for (const vehicle of vehicles) {
      const score = this.calculateAIScore(vehicle, preferences, userType)
      if (score > 0.7) {
        recommendations.push({
          vehicleId: vehicle.id,
          score,
          reasons: this.generateReasons(vehicle, preferences),
          warnings: this.generateWarnings(vehicle),
          financialAdvice: this.generateFinancialAdvice(vehicle, userType),
          negotiationTips: this.generateNegotiationTips(vehicle),
        })
      }
    }

    return recommendations.sort((a, b) => b.score - a.score).slice(0, 8)
  }

  static async analyzeMarket(vehicleId: string): Promise<{
    priceEvolution: string
    recommendation: string
    confidence: number
    insights: string[]
  }> {
    await new Promise((resolve) => setTimeout(resolve, 800))

    return {
      priceEvolution: "decreasing",
      recommendation: "Bon moment pour acheter, les prix baissent",
      confidence: 0.85,
      insights: [
        "Les prix de ce modèle ont baissé de 8% ces 3 derniers mois",
        "Forte disponibilité sur le marché",
        "Nouveau modèle annoncé pour 2025",
      ],
    }
  }

  static async optimizeListing(vehicle: Partial<Vehicle>): Promise<{
    titleSuggestion: string
    descriptionSuggestion: string
    priceSuggestion: number
    improvementTips: string[]
  }> {
    await new Promise((resolve) => setTimeout(resolve, 1200))

    return {
      titleSuggestion: `${vehicle.brand} ${vehicle.model} ${vehicle.year} - ${vehicle.mileage?.toLocaleString()}km - Excellent état`,
      descriptionSuggestion: `Magnifique ${vehicle.brand} ${vehicle.model} de ${vehicle.year} en excellent état. Véhicule bien entretenu avec ${vehicle.mileage?.toLocaleString()}km au compteur. Carnet d'entretien à jour, révisions effectuées en concession. Intérieur impeccable, extérieur sans rayures. Véhicule non fumeur, première main. Contrôle technique OK. Visible sur rendez-vous.`,
      priceSuggestion: (vehicle.price || 0) * 0.95,
      improvementTips: [
        "Ajoutez plus de photos de l'intérieur",
        "Mentionnez l'historique d'entretien",
        "Précisez les équipements optionnels",
        "Indiquez si c'est une première main",
      ],
    }
  }

  private static parseNaturalLanguage(query: string) {
    // Simplified NLP parsing
    const budget = query.match(/(\d+)\s*(?:€|euros?)/i)?.[1]
    const brand = query.match(/\b(peugeot|renault|citroën|volkswagen|bmw|mercedes|audi|toyota|ford)\b/i)?.[1]

    return {
      budget: budget ? Number.parseInt(budget) : null,
      brand: brand?.toLowerCase(),
      keywords: query.toLowerCase().split(" "),
    }
  }

  private static getVehiclesFromQuery(parsedQuery: any): Vehicle[] {
    // Return mock filtered vehicles
    return mockVehicles.filter((vehicle) => {
      if (parsedQuery.budget && vehicle.price > parsedQuery.budget) return false
      if (parsedQuery.brand && vehicle.brand.toLowerCase() !== parsedQuery.brand) return false
      return true
    })
  }

  private static calculateAIScore(vehicle: Vehicle, preferences: UserPreferences, userType: string): number {
    let score = 0

    // Budget compatibility
    if (vehicle.price >= preferences.budget.min && vehicle.price <= preferences.budget.max) {
      score += 0.3
    }

    // AI rating weight
    score += vehicle.aiRating * 0.2

    // Quality-price ratio
    score += vehicle.qualityPriceRatio * 0.2

    // User type specific scoring
    if (userType === "professionnel") {
      score += vehicle.reliabilityScore * 0.15
      score += (10 - vehicle.maintenanceCost) * 0.15
    } else {
      score += vehicle.resaleValue * 0.15
      score += vehicle.popularityScore * 0.15
    }

    return Math.min(1, score)
  }

  private static generateReasons(vehicle: Vehicle, preferences: UserPreferences): string[] {
    const reasons = []

    if (vehicle.aiRating >= 8.5) {
      reasons.push(`Excellente note IA (${vehicle.aiRating}/10)`)
    }

    if (vehicle.qualityPriceRatio >= 8) {
      reasons.push("Excellent rapport qualité-prix")
    }

    if (vehicle.price <= preferences.budget.max * 0.8) {
      reasons.push("Prix très attractif dans votre budget")
    }

    if (vehicle.mileage < 50000) {
      reasons.push("Faible kilométrage")
    }

    return reasons.slice(0, 3)
  }

  private static generateWarnings(vehicle: Vehicle): string[] {
    const warnings = []

    if (vehicle.mileage > 150000) {
      warnings.push("Kilométrage élevé")
    }

    if (vehicle.year < 2015) {
      warnings.push("Véhicule ancien")
    }

    if (vehicle.maintenanceCost > 7) {
      warnings.push("Coûts d'entretien potentiellement élevés")
    }

    return warnings
  }

  private static generateFinancialAdvice(vehicle: Vehicle, userType: string): string {
    if (userType === "professionnel") {
      return `TCO estimé: ${Math.round(vehicle.price * 0.15)}€/an. Déductibilité fiscale possible selon usage.`
    } else {
      const monthlyPayment = Math.round(vehicle.price / 60)
      return `Financement estimé: ${monthlyPayment}€/mois sur 5 ans. Assurance estimée: ${Math.round(vehicle.price * 0.08)}€/an.`
    }
  }

  private static generateNegotiationTips(vehicle: Vehicle): string[] {
    const tips = []

    if (vehicle.marketAnalysis.priceEvolution === "decreasing") {
      tips.push("Les prix baissent, vous pouvez négocier")
    }

    if (vehicle.mileage > 100000) {
      tips.push("Négociez en mentionnant le kilométrage élevé")
    }

    tips.push("Demandez l'historique d'entretien complet")
    tips.push("Vérifiez l'état des pneus et freins")

    return tips.slice(0, 3)
  }
}

// Mock data
const mockVehicles: Vehicle[] = [
  {
    id: "1",
    title: "Peugeot 208 GT Line 1.2 PureTech 100ch",
    brand: "Peugeot",
    model: "208",
    variant: "GT Line",
    year: 2022,
    price: 18500,
    originalPrice: 19500,
    mileage: 25000,
    fuelType: "Essence",
    transmission: "Manuelle",
    power: 100,
    consumption: 5.2,
    co2Emissions: 118,
    doors: 5,
    seats: 5,
    color: "Blanc",
    category: "Citadine",
    bodyType: "Berline",
    images: ["/placeholder.svg?height=300&width=400"],
    description: "Peugeot 208 en excellent état, première main, carnet d'entretien suivi.",
    features: ["Climatisation", "GPS", "Bluetooth", "Régulateur de vitesse"],
    location: "Paris (75)",
    seller: {
      id: "s1",
      name: "Jean Dupont",
      type: "particulier",
      rating: 4.8,
      phone: "06 12 34 56 78",
      location: "Paris",
      verified: true,
    },
    source: "leboncoin",
    aiRating: 8.7,
    qualityPriceRatio: 8.5,
    reliabilityScore: 8.2,
    maintenanceCost: 6.5,
    resaleValue: 7.8,
    popularityScore: 9.1,
    marketAnalysis: {
      priceEvolution: "stable",
      recommendation: "good_deal",
      confidence: 0.87,
    },
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]
