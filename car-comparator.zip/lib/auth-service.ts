import type { AuthUser, LoginCredentials, SignupCredentials, User } from "@/types"

export class AuthService {
  private static users: AuthUser[] = [
    {
      id: "1",
      email: "demo@carwize.ai",
      name: "Utilisateur Demo",
      avatar: "/placeholder.svg?height=40&width=40",
      emailVerified: true,
      createdAt: new Date("2024-01-01"),
      lastLoginAt: new Date(),
    },
    {
      id: "2",
      email: "pro@carwize.ai",
      name: "Pro Demo",
      emailVerified: true,
      createdAt: new Date("2024-01-15"),
      lastLoginAt: new Date(),
    },
  ]

  static async login(credentials: LoginCredentials): Promise<{ user: AuthUser; token: string }> {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const user = this.users.find((u) => u.email === credentials.email)

    if (!user) {
      throw new Error("Email ou mot de passe incorrect")
    }

    // In real app, verify password hash
    if (credentials.password !== "demo123") {
      throw new Error("Email ou mot de passe incorrect")
    }

    // Update last login
    user.lastLoginAt = new Date()

    return {
      user,
      token: `token_${user.id}_${Date.now()}`,
    }
  }

  static async signup(credentials: SignupCredentials): Promise<{ user: AuthUser; token: string }> {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Check if email already exists
    if (this.users.find((u) => u.email === credentials.email)) {
      throw new Error("Cette adresse email est déjà utilisée")
    }

    // Validate password
    if (credentials.password !== credentials.confirmPassword) {
      throw new Error("Les mots de passe ne correspondent pas")
    }

    if (credentials.password.length < 6) {
      throw new Error("Le mot de passe doit contenir au moins 6 caractères")
    }

    // Create new user
    const newUser: AuthUser = {
      id: (this.users.length + 1).toString(),
      email: credentials.email,
      name: credentials.name,
      emailVerified: false,
      createdAt: new Date(),
      lastLoginAt: new Date(),
    }

    this.users.push(newUser)

    return {
      user: newUser,
      token: `token_${newUser.id}_${Date.now()}`,
    }
  }

  static async logout(): Promise<void> {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 500))
    // In real app, invalidate token
  }

  static async getCurrentUser(token: string): Promise<AuthUser | null> {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 300))

    // Extract user ID from token (simplified)
    const userId = token.split("_")[1]
    return this.users.find((u) => u.id === userId) || null
  }

  static async updateProfile(userId: string, updates: Partial<AuthUser>): Promise<AuthUser> {
    await new Promise((resolve) => setTimeout(resolve, 800))

    const userIndex = this.users.findIndex((u) => u.id === userId)
    if (userIndex === -1) {
      throw new Error("Utilisateur non trouvé")
    }

    this.users[userIndex] = { ...this.users[userIndex], ...updates }
    return this.users[userIndex]
  }

  static async sendPasswordReset(email: string): Promise<void> {
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const user = this.users.find((u) => u.email === email)
    if (!user) {
      throw new Error("Aucun compte associé à cette adresse email")
    }

    // In real app, send email
    console.log(`Password reset email sent to ${email}`)
  }

  static createFullUser(authUser: AuthUser, userType: "particulier" | "professionnel"): User {
    return {
      id: authUser.id,
      email: authUser.email,
      name: authUser.name,
      type: userType,
      subscription: "gratuite",
      aiSearchesUsed: 0,
      createdAt: authUser.createdAt,
      preferences: {
        budget: { min: 0, max: 50000 },
        usage: [],
        fuelType: [],
        categories: [],
        location: "",
        notifications: true,
      },
    }
  }
}
